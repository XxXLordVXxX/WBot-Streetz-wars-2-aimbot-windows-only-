if you are here is because you downloaded streetz wars 2 aimbot so if you want to start it join streetz wars and execute the file called sw2aimbot.bat 
MAKE SURE THAT YOU ARE INGAME! 
『₩』CyberCriminals